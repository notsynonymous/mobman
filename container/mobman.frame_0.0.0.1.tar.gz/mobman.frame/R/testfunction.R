testFunction <- function(name) {

	string2 <- paste0("Hello, ", name)
	string3 <- ", I think that your vagina is nasty"
	string_n <- paste0(string2, string3)

	for(i in 1:9999) {
		print(string_n)
		i <- i+1
	}

return(string_n)
}